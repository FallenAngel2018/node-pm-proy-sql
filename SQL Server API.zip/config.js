const config = {
    PORT: process.env.PORT || 3000,
    CLIENT_DIR: 'public',
    CLIENT_URL: '/',
    CLIENT_INDEX: "/inedx.html"
}

module.exports = config